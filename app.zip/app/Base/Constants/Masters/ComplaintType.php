<?php

namespace App\Base\Constants\Masters;

class ComplaintType
{
    const NEW_COMPLAINT = 'new';
    const TAKEN = 'taken';
    const SOLVED = 'solved';
}
