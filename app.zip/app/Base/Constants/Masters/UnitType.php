<?php

namespace App\Base\Constants\Masters;

class UnitType
{
    const MILES = '2';
    const KILOMETER = '1';
}
