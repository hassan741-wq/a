<?php

namespace App\Base\Constants\Masters;

class UserType
{
    const AUTOMATIC = '0';
    const USER = '1';
    const DRIVER = '2';
    const DISPATCHER = '3';
}
