<?php

namespace App\Base\Constants\Masters;

class WithdrawalRequestStatus
{
    const REQUESTED = 0;
    const APPROVED = 1;
    const DECLINED = 2;
}
