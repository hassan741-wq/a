<?php

namespace App\Base\Constants\Taxi;

class UserType
{
    const USER = 'user';
    const DRIVER = 'driver';
    const DISPATCHER = 'dispatcher';
}
