<?php

namespace App\Base\Constants\Taxi;

class AdminCommissionType
{
    const FIXED = 0;
    const PERCENTAGE = 1;
}
