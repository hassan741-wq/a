<?php

namespace App\Base\Constants\Taxi;

class ZoneRideType {
    const RIDENOW = 1;
    const RIDELATER = 2;
}