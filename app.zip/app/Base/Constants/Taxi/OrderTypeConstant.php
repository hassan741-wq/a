<?php

namespace App\Base\Constants\Taxi;

class OrderTypeConstant
{
    const RIDENOW = 'ridenow';
    const SCHEDULED = 'scheduled';
    const RIDENOW_AND_SCHEDULED = 'ridenow-and-scheduled';
}
