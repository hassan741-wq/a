<?php

namespace App\Base\Constants\Setting;

class SettingValueType
{
    const SELECT = 'select';
    const TEXT = 'text';
    const FILE = 'file';
    const PASSWORD = 'password';
}
