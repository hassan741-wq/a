<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Model;

class OwnerHiredDriver extends Model
{
    protected $fillable = ['owner_id','driver_id'];
}
