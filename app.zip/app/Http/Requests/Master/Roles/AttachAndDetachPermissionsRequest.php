<?php

namespace App\Http\Requests\Master\Roles;

use App\Http\Requests\BaseRequest;

class AttachAndDetachPermissionsRequest extends BaseRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [

        ];
    }
}
